<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code igniter crud</title>

    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.min.css">

    
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
  <script>
  $( function() {
    $( ".datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
  } );
  </script>
</head>
<body>
<div class="container">

<div class="row">
    <div class="text-right ">
        <a href="<?php echo base_url().'index.php/user/create'; ?>" class="btn btn-primary">create</a>
    </div>
</div>

<hr>
<div class="row">
<form method="post" name="searchUser" action="<?php echo base_url().'index.php/user/index'; ?>">   
<div class="container">
   <div class='col-md-5'>
      <div class="form-group">
         <div class='input-group date' >
            <input type='text 'name="date1" class="form-control datepicker"  id='date1'/>
            <span class="input-group-addon">
            <span class="glyphicon glyphicon-calendar"></span>
            </span>
         </div>
      </div>
   </div>
   <div class='col-md-5'>
      <div class="form-group">
         <div class='input-group date'>
            <input type='text' name="date2" class="form-control datepicker"  id='date2'/>
            <span class="input-group-addon">
            <span class="glyphicon glyphicon-calendar"></span>
            </span>
         </div>
      </div>
   </div>

   <button type="submit" class="btn btn-primary">Search</button>


</div>
</form>



</div>

<form class="form-inline" role="form" action="<?php echo site_url().'/user/search_keyword';?>" method="post">
       <div class="form-group">
           <input type="text" class="form-control" name="search" placeholder="Search by name or email">
       </div>
<button type="submit" class="btn btn-info" name="submit" >Search</button>
   </form>

    <table class="table">
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Date</th>
            <th>Edit</th>
            <th>delete</th>
        </tr>
         <?php if(!empty($users)) {foreach($users as $user){?>
        <tr>

        <td><?php echo $user['user_id'];?></td>
        <td><?php echo $user['name'];?></td>
        <td><?php echo $user['email'];?></td>
        <td><small><i><?php echo $user['date'];?></i></small></td>
        <td>
            <a href="<?php echo base_url().'index.php/user/edit/'.$user['user_id']?>" class="btn btn-primary">Edit</a>
         </td>
         <td>
            <a href="<?php echo base_url().'index.php/user/delete/'.$user['user_id']?>" class="btn btn-danger">Delete</a>
         </td>
        </tr>
        <?php }} else{ ?>

            <tr>
                <th>records not found</th>
        </tr>

       <?php } ?>

       <p><?php echo $links; ?></p>

     
        

    </table>
</div>
</div>
    
</body>
</html>