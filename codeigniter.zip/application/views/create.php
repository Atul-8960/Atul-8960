<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code igniter crud</title>

    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</head>
<body>
<div class="container">
<form method="post" name="createUser" action="<?php echo base_url().'index.php/user/create'; ?>">
 
  <div class="form-group ">
    <label for="exampleInputName1">Name</label>
    <input type="text" name="name" class="form-control" id="exampleInputName1" aria-describedby="emailHelp" value="<?php echo set_value('name');?>" placeholder="Enter name">
    <?php echo form_error('name'); ?>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" name="email" class="form-control" id="exampleInputEmail1"  value="<?php echo set_value('email'); ?>" placeholder="Enter Email">
    <?php echo form_error('email'); ?>

  </div>
  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
  <a href="<?php echo base_url().'index.php/user/index';?>" class="btn btn-secondary">View</a>

</form>
</div>
    
</body>
</html>