<?php

class User_model extends CI_model {

    function create($formArray){
        $this->db->insert('users', $formArray);
    }

    function all($date1,$date2) {
        if(!$date1 && !$date2){
        return $users = $this->db->get('users') ->result_array();
        }
        else{
            $this->db->where('date >=', $date1);
            $this->db->where('date <=', $date2);
            return $users = $this->db->get('users') ->result_array();

        }
    }


    function getUser($userId) {
        $this->db->where('user_id', $userId);
       return $user = $this->db->get('users')->row_array();
    }

    function updateUser($userId, $formArray){
        $this->db->where('user_id', $userId);
        $this->db->update('users', $formArray);
    }

    function deleteUser($userId){
        $this->db->where('user_id', $userId);
        $this->db->delete('users');
    }


    public function paginateList($limit,$offset)
    {
     $q=$this->db->select('*')
              ->from('users')
              ->limit($limit,$offset)
              ->get();
              echo $this->db->last_query();
             return $q->result_array();
    }

    function search($keyword)
    {
        $this->db->like('name',$keyword);
        $this->db->or_like('email',$keyword);
        $query  = $this->db->get('users');
        return $query->result_array();
    }

    function record_count(){        
        $this->db->from('users');         
        $query = $this->db->get();
        $row = $query->num_rows();
        return $row;
    }


    
}

?>